"""Dokapon reverse-engineering helpers."""

